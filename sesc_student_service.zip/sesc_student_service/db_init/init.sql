ALTER USER 'appuser'@'%' IDENTIFIED BY 'apppass' WITH mysql_native_password;
